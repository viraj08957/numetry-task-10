/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React from "react";

export default function SectionHeader({ children }) {
  return <div className="section--header">{children}</div>;
}
